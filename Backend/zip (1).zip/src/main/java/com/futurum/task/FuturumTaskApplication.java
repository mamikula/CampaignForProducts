package com.futurum.task;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FuturumTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(FuturumTaskApplication.class, args);
	}

}
